Logan Gilmour

1174141

My application is running at http://ikno.ws - its source is index.php.

My SOAP server is running at http://ikno.ws/lserve.php - its source is lserve.php.

My web-service is described by catalog.wsdl

I implemented this application in php using nusoap.
